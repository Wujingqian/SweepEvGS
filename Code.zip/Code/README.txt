This is the README file for our uploaded code and sample data.
The point_cloud.ply file is our trained 3D-GS radiance field point cloud, for reproducibility.
The Data folder contained the blurry frames and the event stream captured.